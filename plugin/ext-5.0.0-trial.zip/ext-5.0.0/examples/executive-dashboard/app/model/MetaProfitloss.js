Ext.define('ExecDashboard.model.MetaProfitloss', {
    extend: 'ExecDashboard.model.Base',

    fields: [
        'display',
        'quarter',
        'region'
    ]
});
